﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for NonProfit
/// </summary>
public class NonProfit
{
    private int orgID;
    private String orgName;
    private String orgPhoneNbr;
    private String orgEmail;
    private String orgField;
    private String orgLiaison;
    private String orgPassword;
    

    public NonProfit(String orgName, String phoneNbr, String email, String field, String liaison, String password)

    {
        //setOrgID(orgID);
        setOrgName(orgName);
        setOrgPhoneNbr(phoneNbr);
        setOrgEmail(email);
        setOrgField(field);
        setOrgLiaison(liaison);
        setOrgPassword(password);
    }

    public void setOrgID(int orgID)
    {
        this.orgID = orgID;
    }

    public int getOrgID()
    {
        return orgID;
    }

    public void setOrgName(String orgName)
    {
        this.orgName = orgName;
    }

    public String getOrgName()
    {
        return orgName;
    }

    public void setOrgPhoneNbr(String orgPhoneNbr)
    {
        this.orgPhoneNbr = orgPhoneNbr;
    }

    public String getOrgPhoneNbr()
    {
        return orgPhoneNbr;
    }

    public void setOrgEmail(String orgEmail)
    {
        this.orgEmail = orgEmail;
    }

    public String getOrgEmail()
    {
        return orgEmail;
    }

    public void setOrgField(String orgField)
    {
        this.orgField = orgField;
    }

    public String getOrgField()
    {
        return orgField;
    }

    public void setOrgLiaison(String orgLiaison)
    {
        this.orgLiaison = orgLiaison;
    }

    public String getOrgLiaison()
    {
        return orgLiaison;
    }

    public void setOrgPassword(String orgPassword)
    {
        this.orgPassword = orgPassword;
    }

    public String getOrgPassword()
    {
        return orgPassword;
    }

    
}
