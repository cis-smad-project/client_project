﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for NonProfit
/// </summary>
public class NonProfit2
{
    private string orgEmail;
    private string orgName;
    private string orgPhoneNbr;

    public NonProfit2(string orgEmail, string orgName, string orgPhoneNbr)
    {
        setOrgEmail(orgEmail);
        setOrgName(orgName);
        setOrgPhoneNbr(orgPhoneNbr);
    }

    public void setOrgName(string orgName)
    {
        this.orgName = orgName;
    }

    public string getOrgName()
    {
        return orgName;
    }

    public void setOrgPhoneNbr(string orgPhoneNbr)
    {
        this.orgPhoneNbr = orgPhoneNbr;
    }

    public string getOrgPhoneNbr()
    {
        return orgPhoneNbr;
    }

    public void setOrgEmail(string orgEmail)
    {
        this.orgEmail = orgEmail;
    }

    public string getOrgEmail()
    {
        return orgEmail;
    }
}
