﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for NonProfitAddress
/// </summary>
public class NonProfitAddress
{
    private String orgHouseNum;
    private String orgStreet;
    private String orgCity;
    private String orgState;
    private String orgZip;
    private String orgCountry; 


    public NonProfitAddress(String orgHouseNum, String orgStreet, String orgCity, String orgState, String orgZip, String orgCountry)
    {
        setOrgHouseNum(orgHouseNum);
        setOrgStreet(orgStreet);
        setOrgCity(orgCity);
        setOrgState(orgState);
        setOrgZip(orgZip);
        setOrgCountry(orgCountry);
    }

    public void setOrgHouseNum(String orgHouseNum)
    {
        this.orgHouseNum = orgHouseNum;
    }

    public String getOrgHouseNum()
    {
        return this.orgHouseNum;
    }

    public void setOrgStreet(String orgStreet)
    {
        this.orgStreet = orgStreet;
    }

    public String getOrgStreet()
    {
        return this.orgStreet;
    }

    public void setOrgCity(String orgCity)
    {
        this.orgCity = orgCity;
    }

    public String getOrgCity()
    {
        return this.orgCity;
    }

    public void setOrgState(String orgState)
    {
        this.orgState = orgState;
    }

    public String getOrgState()
    {
        return this.orgState;
    }

    public void setOrgZip(String orgZip)
    {
        this.orgZip = orgZip;
    }

    public String getOrgZip()
    {
        return this.orgZip;
    }

    public void setOrgCountry(String orgCountry)
    {
        this.orgCountry = orgCountry;
    }

    public String getOrgCountry()
    {
        return this.orgCountry;
    }
}