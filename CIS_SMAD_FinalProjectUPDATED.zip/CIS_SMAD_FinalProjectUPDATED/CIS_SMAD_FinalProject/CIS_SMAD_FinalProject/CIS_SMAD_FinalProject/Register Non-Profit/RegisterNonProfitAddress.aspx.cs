﻿using System;
using System.Web;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.UI;
using System.Reflection;

public partial class RegisterNonProfit_RegisterNonProfitAddress : System.Web.UI.Page
{
    System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["CapPractice"].ToString());

    protected void Page_Load(object sender, EventArgs e)
    {
        ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
    }

    protected void EnterBtn_Click(object sender, EventArgs e)
    {
        NonProfitAddress tempAddress = new NonProfitAddress(TxtNonProfitHouseNum.Text, txtNonProfitStreet.Text, txtNonProfitCity.Text, dlNonProfitState.SelectedValue, txtZipCode.Text, txtCountry.Text); 
        sc.Open();
        SqlCommand enter = new SqlCommand();
        enter.Connection = sc;

        enter.CommandText = "Insert into [CapPractice].[dbo].[Address] values (@HouseNum, @Street, @City, @State, @Country, @Zip)";
        enter.Parameters.AddWithValue("@HouseNum", HttpUtility.HtmlEncode(tempAddress.getOrgHouseNum()));
        enter.Parameters.AddWithValue("@Street", HttpUtility.HtmlEncode(tempAddress.getOrgStreet()));
        enter.Parameters.AddWithValue("@City", HttpUtility.HtmlEncode(tempAddress.getOrgCity()));
        enter.Parameters.AddWithValue("@State", HttpUtility.HtmlEncode(tempAddress.getOrgState()));
        enter.Parameters.AddWithValue("@Country", HttpUtility.HtmlEncode(tempAddress.getOrgCountry()));
        enter.Parameters.AddWithValue("@Zip", HttpUtility.HtmlEncode(tempAddress.getOrgZip()));
        enter.ExecuteNonQuery();
        sc.Close();

        Response.Redirect("RegisterNonProfitInformation.aspx");
    }


}