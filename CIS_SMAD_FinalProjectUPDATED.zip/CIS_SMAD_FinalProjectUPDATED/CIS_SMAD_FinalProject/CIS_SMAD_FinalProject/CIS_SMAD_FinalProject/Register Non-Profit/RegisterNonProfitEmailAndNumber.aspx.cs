﻿using System;
using System.Web;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.UI;


    public partial class RegisterNonProfitEmailAndNumber : System.Web.UI.Page
    {
        
    protected void Page_Load(object sender, EventArgs e)
        {
        ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }


        protected void EnterBtn_Click(object sender, EventArgs e)
        {

            Session["orgName"] = txtorgName.Text;
            Session["orgEmail"] = txtorgEmail.Text;
            Session["orgPhone"] = txtorgPhoneNum.Text;

        Response.Redirect("RegisterNonProfitPassword.aspx");
        }

    }

