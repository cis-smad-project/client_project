﻿using System;
using System.Web;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.UI;
using System.Reflection;


    public partial class RegisterNonProfit_RegisterNonProfitInformation : System.Web.UI.Page
    {
        System.Data.SqlClient.SqlConnection sc = new System.Data.SqlClient.SqlConnection(ConfigurationManager.ConnectionStrings["CapPractice"].ToString());


        protected void Page_Load(object sender, EventArgs e)
        {
            ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }


        protected void EnterBtn_Click(object sender, EventArgs e)
        {


           sc.Open();
            NonProfit tempNonProfit = new NonProfit(Session["orgName"].ToString(), Session["orgPhone"].ToString(), Session["orgEmail"].ToString(), dlFieldType.SelectedValue, txtLiaisonName.Text, Session["password"].ToString());

            SqlCommand insert = new SqlCommand();
            insert.Connection = sc;

            SqlCommand commit = new SqlCommand();
            commit.Connection = sc;


            commit.CommandText = "Insert into [CapPractice].[dbo].[Login] values(@Email, @Password)";

            insert.CommandText = "Insert into [CapPractice].[dbo].[NonProfit] values (@OrgName, @OrgPhone, @OrgField, @OrgLiaison)";
                        
            insert.Parameters.AddWithValue("@OrgName", HttpUtility.HtmlEncode(tempNonProfit.getOrgName()));
            insert.Parameters.AddWithValue("@OrgPhone", HttpUtility.HtmlEncode(tempNonProfit.getOrgPhoneNbr()));
            insert.Parameters.AddWithValue("@OrgField", HttpUtility.HtmlEncode(tempNonProfit.getOrgField())); 
            commit.Parameters.AddWithValue("@Email", HttpUtility.HtmlEncode(tempNonProfit.getOrgEmail()));
            insert.Parameters.AddWithValue("@OrgLiaison", HttpUtility.HtmlEncode(tempNonProfit.getOrgLiaison()));
            commit.Parameters.AddWithValue("@Password", HttpUtility.HtmlEncode(tempNonProfit.getOrgPassword()));
            


            insert.ExecuteNonQuery();
            commit.ExecuteNonQuery();
            
    }

    
}
