﻿using System;
using System.Web;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Web.UI;
using System.Reflection;

public partial class RegisterPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ValidationSettings.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
    }

    protected void EnterBtn_Click(object sender, EventArgs e)
    {
        Session["password"] = txtPassword.Text;
        Session["confirmPassword"] = txtConfirmPass.Text;
        Response.Redirect("RegisterNonProfitAddress.aspx");
    }
}